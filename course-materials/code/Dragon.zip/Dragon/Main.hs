module Main where
import Prelude hiding (Left, Right)
import Graphics.Gloss

{-

To run this program you have to have Gloss installed.
You can probably try

   cabal install gloss

execute with

  ghci -fno-ghci-sandbox Main.hs

evaluate

  dragon n

where n is the level.
-}

import Dragon

data Dir = Left | Up | Right | Down

nextDir :: Dir -> Turn -> Dir
nextDir Left   L = Down
nextDir Left   R = Up
nextDir Up     L = Left
nextDir Up     R = Right
nextDir Right  L = Up
nextDir Right  R = Down
nextDir Down   L = Right
nextDir Down   R = Left

nextLoc :: Float -> Dir -> Point -> Point
nextLoc len Left  (x,y) = (x-len, y)
nextLoc len Up    (x,y) = (x, y+len)
nextLoc len Right (x,y) = (x+len, y)
nextLoc len Down  (x,y) = (x, y-len)

turnsToPath :: Float -> Dir -> Point -> List Turn -> Path
turnsToPath len d loc []     = [loc, nextLoc len d loc]
turnsToPath len d loc (t:ts) = loc : turnsToPath len (nextDir d t) (nextLoc len d loc) ts

---

window :: Display
window = InWindow "Dragon Curve" (700, 700) (10, 10)

background :: Color
background = white

drawing :: Int -> Picture
drawing n = scaleToFit path
  where turns = dragonI n
        len = 1 -- 250 / ((sqrt 2)^(fromIntegral n))
        path = turnsToPath len Up (0,0) turns


scaleToFit :: Path -> Picture
scaleToFit path = Scale sFactor sFactor .
                  Translate (- minX - (maxX - minX) / 2)
                            (- minY - (maxY - minY) / 2)
                   $ Line path
  where maxX = maximum (map fst path)
        minX = minimum (map fst path)
        maxY = maximum (map snd path)
        minY = minimum (map snd path)
        sFactor = 0.8 * 700 / (maxX - minX) `max` (maxY - minY)

---

dragon n = display window background (drawing n)

main :: IO ()
main = display window background (drawing 12)
